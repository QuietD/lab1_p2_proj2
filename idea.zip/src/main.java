
import java.time.LocalDateTime;
import java.util.*;
class Person{
    String _name;
    String _surname;
    int _birthYear;
    int _birthMonth;
    public Person(String name,String surname, int birthYear, int birthMonth){
        this._birthMonth=birthMonth;
        this._birthYear = birthYear;
        this._name = name;
        this._surname = surname;
    }
}
public class main {

    public static void main(String[] args) {
        ArrayList<Person> Persons = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        while(true) {


            System.out.println("Possible actions:\n1)Add person\n2)Edit person\n3)Oldest person\n4)Sort list of persons\n5)Avarage age\nChoose an option: ");

            switch (sc.nextInt()) {
                case 1:
                    Persons = addPerson(Persons);
                    break;
                case 2:
                    Persons = editPerson(Persons);
                    break;
                case 3:
                    oldestPerson(Persons);
                    break;
                case 4:
                    Persons = sortList(Persons);
                    break;
                case 5:
                    avarageAge(Persons);
                    break;
                default:
                    System.out.println("Inncorrect variant");
                    break;
            }
        }

    }
    static void oldestPerson(ArrayList<Person> Persons){
        int oldestAge =0;
        int counter = 0;
        for (int i=0;i<Persons.size();i++){
            int age = LocalDateTime.now().getYear()-Persons.get(i)._birthYear;
            if(LocalDateTime.now().getMonthValue()>Persons.get(i)._birthMonth){
                age++;
            }
            if(oldestAge<age){
                oldestAge=age;
                counter=i;
            }
        }
        System.out.println("Oldest person is:");
        System.out.printf("Name:%s\nSurname:%s\nYear of birth:%d\nMonth of birth:%d\n",
                Persons.get(counter)._name,
                Persons.get(counter)._surname,
                Persons.get(counter)._birthYear,
                Persons.get(counter)._birthMonth);
    }
    static ArrayList<Person> sortList(ArrayList<Person> Persons){
        ArrayList<String> Surnames = new ArrayList<>();
        HashMap<String,Integer>surnames=new HashMap<>();
        for(int i = 0;i<Persons.size();i++){
            Surnames.add(Persons.get(i)._surname);
            surnames.put(Persons.get(i)._surname,i);
        }
        Collections.sort(Surnames);
        ArrayList<Person> persons = new ArrayList<>();
        persons=Persons;
        for(int i = 0;i<surnames.size();i++){
            persons.set(i,Persons.get(surnames.get(Surnames.get(i))));
        }
        Collections.reverse(persons);
        return persons;
    }
    static void avarageAge(ArrayList<Person> Persons){
        double avarageAge=0;
        int yearNow = LocalDateTime.now().getYear();
        System.out.println("");
         for(int i = 0;i<Persons.size();i++){
            avarageAge+=(yearNow-Persons.get(i)._birthYear);
        }
        avarageAge=avarageAge/Persons.size();
        System.out.println("Avarage age: "+avarageAge);
        System.out.println("Persons above avarage age:");
        for(int i = 0,age;i<Persons.size();i++){
            age = yearNow-Persons.get(i)._birthYear;
            if(age>avarageAge){
                System.out.printf("Name:%s\nSurname:%s\nYear of birth:%d\nMonth of birth:%d\n",
                        Persons.get(i)._name,
                        Persons.get(i)._surname,
                        Persons.get(i)._birthYear,
                        Persons.get(i)._birthMonth);
            }
        }
    }
    static ArrayList<Person> addPerson(ArrayList<Person> Persons){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter name of person: ");
        String name = sc.next();
        System.out.print("Enter surname of person: ");
        String surname = sc.next();
        System.out.print("Enter the person's year of birth: ");
        int birthYear = sc.nextInt();
        System.out.print("Enter the person's month of birth(using numbers): ");
        int birthMonth = sc.nextInt();
        Persons.add(new Person(name,surname,birthYear,birthMonth));
        return Persons;
    }
    static ArrayList<Person> editPerson(ArrayList<Person> Persons){
        if(Persons.isEmpty()){
            System.out.println("List is empty");
            return Persons;
        }
        ArrayList<Integer> counter = new ArrayList<Integer>();
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a surname of person to search: ");
        String surname = sc.next();
        for(int i = 0;i<Persons.size();i++){
            if(Persons.get(i)._surname.equals(surname)){
                counter.add(i);
            }
        }
        if(!counter.isEmpty()){
            if(counter.size()>1){
                System.out.println("Founded multiple matches:");
                for(int i = 0;i<counter.size();i++){
                    System.out.printf("%d)\nName:%s\nSurname:%s\nYear of birth:%d\nMonth of birth:%d\n",
                            i,
                            Persons.get(counter.get(i))._name,
                            Persons.get(counter.get(i))._surname,
                            Persons.get(counter.get(i))._birthYear,
                            Persons.get(counter.get(i))._birthMonth);
                }
                System.out.print("Choose necessary person: ");
                int ch = sc.nextInt();
                Persons.set(counter.get(ch),edit(Persons.get(counter.get(ch))));
                System.out.printf("Edited person:\nName:%s\nSurname:%s\nYear of birth:%d\nMonth of birth:%d\n",
                        Persons.get(counter.get(ch))._name,
                        Persons.get(counter.get(ch))._surname,
                        Persons.get(counter.get(ch))._birthYear,
                        Persons.get(counter.get(ch))._birthMonth);

            }
            else{
                Persons.set(counter.get(0),edit(Persons.get(counter.get(0))));
                System.out.printf("Edited person:\nName:%s\nSurname:%s\nYear of birth:%d\nMonth of birth:%d\n",
                        Persons.get(counter.get(0))._name,
                        Persons.get(counter.get(0))._surname,
                        Persons.get(counter.get(0))._birthYear,
                        Persons.get(counter.get(0))._birthMonth);
            }
        }
        else {
            System.out.println("Not found");
        }
        return Persons;
    }
    static Person edit(Person person){
        Scanner sc = new Scanner(System.in);
        boolean incr;
        do {
            System.out.print("What you want to edit:\n 1)Name\n 2)Surname\n 3)Year of birth\n 4)Month of birth\n Choose your option: ");
            incr = false;
            switch (sc.nextInt()) {
                case 1:
                    System.out.print("Enter new name: ");
                    person._name = sc.next();
                    return person;
                case 2:
                    System.out.print("Enter new surname: ");
                    person._surname = sc.next();
                    return person;
                case 3:
                    System.out.print("Enter new year of birth: ");
                    person._birthYear = sc.nextInt();
                    return person;
                case 4:
                    System.out.print("Enter new month of birth: ");
                    person._birthMonth = sc.nextInt();
                    return person;
                default:
                    System.out.println("Incorrect");
                    incr=true;
                    return person;
            }
        }while(incr);
    }

}
